### Hexlet tests and linter status:
[![Actions Status](https://github.com/230707/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/230707/python-project-49/actions)

<a href="https://codeclimate.com/github/230707/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/aeb1e5827e089df41bc1/maintainability" /></a>

### Аскинема - запуск игры brain-even и победа игрока
<a href="https://asciinema.org/a/NpTTN0Sd2Fvi7shsi3Ki8gfLf" target="_blank"><img src="https://asciinema.org/a/NpTTN0Sd2Fvi7shsi3Ki8gfLf.svg" /></a>

### Аскинема - запуск игры brain-even и проигрыш игрока, а также проигрыш из-за некорректного ответа:
<a href="https://asciinema.org/a/KjMKKe5QAuYn6CFZmbjKYPdwT" target="_blank"><img src="https://asciinema.org/a/KjMKKe5QAuYn6CFZmbjKYPdwT.svg" /></a>

### Аскинема - запуск игры brain-calc с демонстрацией различных исходов игры:
<a href="https://asciinema.org/a/kDHc1sPjdmXitwFUPvJVLDpMW" target="_blank"><img src="https://asciinema.org/a/kDHc1sPjdmXitwFUPvJVLDpMW.svg" /></a>

### Аскинема - запуск игры brain-gcd с демонтсрацией различных исходов игры:
<a href="https://asciinema.org/a/azHJkqdRzw7WoBZ98FekrGUUi" target="_blank"><img src="https://asciinema.org/a/azHJkqdRzw7WoBZ98FekrGUUi.svg" /></a>

### Аскинема - запуск игры brain-progression с демонтсрацией различных исходов игры:
<a href="https://asciinema.org/a/LJZ8xdPdl0lUEgMUoutGM7fZ6" target="_blank"><img src="https://asciinema.org/a/LJZ8xdPdl0lUEgMUoutGM7fZ6.svg" /></a>
