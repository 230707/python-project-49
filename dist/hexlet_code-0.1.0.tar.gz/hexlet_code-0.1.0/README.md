### Hexlet tests and linter status:
[![Actions Status](https://github.com/230707/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/230707/python-project-49/actions)

<a href="https://codeclimate.com/github/230707/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/aeb1e5827e089df41bc1/maintainability" /></a>

### Аскинема - запуск игры и победа игрока
<a href="https://asciinema.org/a/NpTTN0Sd2Fvi7shsi3Ki8gfLf" target="_blank"><img src="https://asciinema.org/a/NpTTN0Sd2Fvi7shsi3Ki8gfLf.svg" /></a>

### Аскинема - запуск игры и проигрыш игрока, а также проигрыш из-за некорректного ответа:
<a href="https://asciinema.org/a/KjMKKe5QAuYn6CFZmbjKYPdwT" target="_blank"><img src="https://asciinema.org/a/KjMKKe5QAuYn6CFZmbjKYPdwT.svg" /></a>